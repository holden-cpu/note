## R0001 - Rx模式的Vertx/Verticle实例

* [Vert.x - From zero to \(micro\) - hero](http://escoffier.me/vertx-hol/) ——Clement Escoffier



