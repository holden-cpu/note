# 1. 锋芒乍现

## 1.1.一切从FP开始

* [改变开发者思维的六种变成范式](http://geek.csdn.net/news/detail/195967)——钱曙光
* [从Java8说起函数式编程](https://www.cnblogs.com/tina-smile/p/5756074.html)——smile\_tina
* [闭包](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Closures)——MDN
* [Pure function](https://en.wikipedia.org/wiki/Pure_function)——WikiPedia
* [Functors,Applicatives,And Monads In Pictures](http://adit.io/posts/2013-04-17-functors,_applicatives,_and_monads_in_pictures.html)
* [Monads模式初探——Monad概念](https://blog.csdn.net/jasonding1354/article/details/50810774)——JasonDing1354

## 1.2.Vert.x基础

* [Vert.x](https://vertx.io/)
* [Web Framework Benchmarks](https://www.techempower.com/benchmarks/#section=data-r8&hw=i7&test=plaintext)
* [A gentle guide to asynchronous programming with Eclipse Vert.x for Java developers](https://vertx.io/docs/guide-for-java-devs/)
* [并发模型与事件循环](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/EventLoop)——MDN

## 1.3.Vertx实例

* [Vert.x Core Manual](https://vertx.io/docs/vertx-core/java/)
* [Vert.x Zero Up Framework](http://www.vertxup.cn/)
* [Vert.x Clustring](https://vertx.io/docs/#clustering)
* [The 'vert.x' command line](https://vertx.io/docs/vertx-core/java/#_the_vertx_command_line)

## 1.4.Verticle实例

* [Verticle Types](https://vertx.io/docs/vertx-core/java/#_verticle_types)
* [Verticles](https://vertx.io/docs/vertx-core/java/#_verticles)

## 1.5.Verticle生命周期

* [Runtime.addShutdownHook用法](http://kim-miao.iteye.com/blog/1662550)——kim\_miao

# 2. 服务的苍穹

## 2.1.正确打开REST

* [Richardson Maturity Model](https://martinfowler.com/articles/richardsonMaturityModel.html)——Leonard Richardson
* [理解HTTP幂等性](http://www.cnblogs.com/weidagang2046/archive/2011/06/04/idempotence.html)——Todd Wei

## 2.3.HttpServer碎碎念

* [Vert.x HTTP Server](http://tutorials.jenkov.com/vert.x/http-server.html)——Jakob Jenkov



