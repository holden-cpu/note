---
title: 3.6.Web开发
---

&ensp;&ensp;&ensp;&ensp;本章我们开始真正进入`vertx-web`开发Web项目和Web服务（RESTful）的领域，我尝试在讲解时对比Java Web开发中的Servlet知识点，让您对Vert.x的Web开发有一个更感性的认知。除了《[3.2.HttpServer初赦](./03-2-http-server.md)》的基础配置外，Vert.x Web支持两种环境模式：默认情况下为生产模式（`Production`），您可以按如下步骤切换到开发模式（`Development`）：

* 设置环境变量：`VERTXWEB_ENVIRONMENT=dev`
* 设置系统属性：`vertxweb.environment=dev`

&ensp;&ensp;&ensp;&ensp;在开发模式下：

* 模板引擎（Template Engine）缓存被禁用。
* `ErrorHandler`不显示异常详细信息。
* `StaticHandler`不处理缓存的HTTP标头。
* `GraphiQL`开发工具被禁用。

# 1. 路由上下文

&ensp;&ensp;&ensp;&ensp;在看`vertx-web`之前，先看一段简单的官方代码：

```java
    // 创建HTTP服务器，每个Verticle中可直接使用`vertx`引用Vertx实例
    HttpServer server = vertx.createHttpServer();

    server.requestHandler(request -> {

        // （请求周期）请求发送过来时范会执行该Handler中的代码
        HttpServerResponse response = request.response();
        response.putHeader("content-type", "text/plain");

        /*
        * （请求周期）生成当前请求的响应
        *  此处请求除了端口号8080，不限制路径和HTTP请求方法信息，
        *  发送任意请求到对应地址都会触发该 Handler 的执行代码。
        */
        response.end("Hello World!");
    });

    // 服务器监听8080端口
    server.listen(8080);
```

&ensp;&ensp;&ensp;&ensp;运行成功后，您可以访问`http://localhost:8080`查看响应信息：

![](./_image/2022-11-09/20221109152015.png)

&ensp;&ensp;&ensp;&ensp;这段代码是`vertx-core`中创建HTTP服务器的标准代码，并没使用`vertx-web`模块，它描述了Vertx中启动`HttpServer`实例的内部原理。将上述代码使用`vertx-web`重写如下：

```java
    // 创建HTTP服务器，每个Verticle中可直接使用`vertx`引用Vertx实例
    final HttpServer server = this.vertx.createHttpServer();

    final Router router = Router.router(this.vertx);
    router.route().handler(context -> {
        final HttpServerResponse response = context.response();
        response.putHeader("content-type", "text/plain");
        response.end("Hello Web!");
    });

    // 服务器监听8080端口
    server.requestHandler(router).listen(8080);
```

&ensp;&ensp;&ensp;&ensp;上述代码运行结果和前一个示例一样，我们创建了一个`Router`对象，在它之下又创建了`Route`对象，随之将`Router`作为`HttpServer`的`requestHandler`方法参数传递。上述两段代码都演示了在Vert.x中如何写一个简单的服务端程序，本章基于`vertx-web`项目，我们再看`RoutingContext`接口（路由上下文）。

