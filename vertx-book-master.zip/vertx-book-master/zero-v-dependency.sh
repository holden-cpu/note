#!/usr/bin/env bash
mvn versions:display-dependency-updates