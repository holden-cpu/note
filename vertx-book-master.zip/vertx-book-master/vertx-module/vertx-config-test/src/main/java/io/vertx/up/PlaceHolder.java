package io.vertx.up;

/**
 * @author <a href="http://www.origin-x.cn">Lang</a>
 */
public class PlaceHolder {
}
