#!/usr/bin/env bash
gitbook build
