#!/usr/bin/env bash
gitbook build
serve _book -p 1231