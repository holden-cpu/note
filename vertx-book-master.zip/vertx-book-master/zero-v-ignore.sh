#!/usr/bin/env bash
# 拷贝核心框架
cp pom-update.xml ./vertx-src/pom-update.xml
cp pom-update.xml ./vertx-module/pom-update.xml
cp pom-update.xml ./vertx-module/vertx-config-test/pom-update.xml