# 本书简介

&ensp;&ensp;&ensp;&ensp;2017年12月，Zero（[http://www.vertxup.cn](http://www.vertxup.cn)）问世，这是在`vert.x`
中的一个深度尝试，最初的目的只是为了填补`vert.x`生态中的一种空缺——类似Spring-Boot的应用框架并没有出现在`vert.x`
的生态中，也许它没有存在的意义，但我还是坚持下来了，这个过程虽然只有短短的三个月，却收获了无数的心得。从最初的`vert.x`的`2.x`
版本到如今的`3.x`
的版本，也经历了无数成长、挣扎、纠结，直到今天也许很多东西都尘埃落定了，回过头来看着这份痕迹，就想到写一份分享`vert.x`
开发心得的教程，这份教程也许不完美，却记录了在Zero诞生过程中对`vert.x`使用的种种。

> &ensp;&ensp;&ensp;&ensp;“故不登高山，不知天之高也；不临深溪，不知地之厚也；不闻先王之遗言，不知学问之大也。” ——《荀子 · 劝学》
>
> &ensp;&ensp;&ensp;&ensp;“君子之学也，入乎耳，著乎心，布乎四体，形乎动静。端而言，蝡而动，一可以为法则。小人之学也，入乎耳，出乎口；口耳之间，则四寸耳，曷足以美七尺之躯哉！”
> ——《荀子 · 劝学》

# 后续支持

- 公众号微信：`vertx_zero`
- 公众号名称：`Zero Framework`
- （后端）Zero Ecotope：<https://www.zerows.io>
- （前端）Zero UI：<https://www.vertxui.cn>
- （工具）Zero AI：<https://www.vertxai.cn>
- （标准）Zero Schema：<https://www.vertx-cloud.cn>

![](/assets/0/qrcode.jpg)

公众号内容：

1. 《逐陆记》的QA和答疑。
2. 《零》系列文章说明，针对Zero框架（[http://www.vertxup.cn](http://www.vertxup.cn)）的教程分享。
3. 前端框架Zero UI（[http://www.vertxui.cn](http://www.vertxui.cn)）的教程分享。
4. 《Zero思然汀》在线地址：<https://lang-yu.gitbook.io/zero/>
5. Zero框架的建议提交、以及框架本身的最新更新信息（包含未发布文档的版本）。

# 本书结构

本书主要包含了四个主要组成部分：

* **楔子**：讲解本书的背景。
* **正章**：《逐陆记》的正篇章节。

本地安装：

1. 在您机器上安装`gitbook-cli`。
2. 从Gitee下载代码：`https://gitee.com/silentbalanceyh/vertx-book`。
3. 执行如下命令：

    ```shell
    gitbook install
    ./book-build.sh
    ./book-server.sh
    ```
3. 然后访问：http://localhost:1231 即可查看。

> 不得不说最近和Gitbook工程师扯皮也扯得比较狠，不知道是不是因为我这边本地配置不对，发布在线的引用显示不正常，最终导致本地化后的结果和在线版本不一致。所以我推荐使用
**本地安装**，这样看起来Gitbook的显示会正常点

本书目录参考：[本书目录](/SUMMARY.md)

