#!/usr/bin/env bash
grep --color=auto -rns "4\.3\.3" .
