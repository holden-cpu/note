package io.vertx.up._03.web;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerResponse;

/**
 * @author <a href="http://www.origin-x.cn">Lang</a>
 */
public class HelloWorld extends AbstractVerticle {

    @Override
    public void start() {
        // 创建HTTP服务器，每个Verticle中可直接使用`vertx`引用Vertx实例
        final HttpServer server = this.vertx.createHttpServer();

        server.requestHandler(request -> {

            // （请求周期）请求发送过来时范会执行该Handler中的代码
            final HttpServerResponse response = request.response();
            response.putHeader("content-type", "text/plain");

            /*
             * （请求周期）生成当前请求的响应
             *  此处请求除了端口号8080，不限制路径和HTTP请求方法信息，
             *  发送任意请求到对应地址都会触发该 Handler 的执行代码。
             */
            response.end("Hello World!");
        });

        // 服务器监听8080端口
        server.listen(8080);
    }
}
