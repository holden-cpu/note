package io.vertx.up._02.async;

import io.vertx.core.Future;
import io.vertx.up.fn.Fn;

import java.util.ArrayList;
import java.util.List;

public class AsyncCombine {
    public static void main(final String[] args) {
        final List<String> nameSet = new ArrayList<>();
        nameSet.add("Lang");
        nameSet.add("Huan");
        nameSet.add("Han");

        Fn.combineT(
            // 为每个人构造打招呼的行为
            nameSet.stream()
                .map(At::hiAsync)
                .toList()
        ).compose(response -> {
            // 最终返回的结果
            response.forEach(System.out::println);
            return Future.succeededFuture();
        });
    }
}
