package io.vertx.rx.x;

import io.reactivex.Single;

public class RxDelay {

    public static void main(final String[] args) {
        Single.just("Hello Lang");
    }
}
