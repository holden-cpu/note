package io.vertx.up._03.rm;

import io.vertx.ext.web.Route;

public interface RAim {

    void mount(final Route route, final RRecord record);
}
