package io.vertx.up._03.web;

import io.vertx.core.DeploymentOptions;
import io.vertx.up._01.lanucher.Launcher;
import io.vertx.up._01.lanucher.SingleLauncher;

/**
 * @author <a href="http://www.origin-x.cn">Lang</a>
 */
public class WebRoute {
    public static void main(final String[] args) {
        final Launcher launcher = new SingleLauncher();
        launcher.start(vertx ->
            vertx.deployVerticle(HelloWeb::new, new DeploymentOptions().setInstances(2)));
    }
}
