package io.vertx.up._02.async;

import io.horizon.atom.program.KRef;
import io.horizon.runtime.Runner;
import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.up.fn.Fn;

import java.util.concurrent.CountDownLatch;

public class AsyncSync {

    public static void main(final String[] args) {
        final String callback = hiCallback();
        System.out.println(callback);
    }

    private static String hiCallback() {
        final Future<String> response = hiChoice("Lang");
        final CountDownLatch latch = new CountDownLatch(1);
        final KRef refer = new KRef();
        response.onComplete(res -> {
            if (res.succeeded()) {
                //
                // Java中的限制 line = res.result();
                refer.add(res.result());
            } else {
                //
                res.cause().printStackTrace();
            }
            latch.countDown();
        });
        // 手动阻塞，破坏黄金法则
        Fn.jvmAt(latch::await);
        return refer.get();
    }

    static Future<String> hiChoice(final String name) {
        final Promise<String> promise = Promise.promise();
        Runner.run(() -> {
            // 当前 执行 不受影响
            System.out.println(Thread.currentThread().getName() + "，" + name);
            Fn.jvmAt(() -> Thread.sleep(1000));
            if ("Lang".equals(name)) {
                promise.complete(name);
            } else {
                promise.fail(new RuntimeException("Exception, " + name));
            }
        }, "hiAsync");
        return promise.future();
    }
}
