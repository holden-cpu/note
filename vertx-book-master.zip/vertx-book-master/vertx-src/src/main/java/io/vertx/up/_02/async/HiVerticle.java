package io.vertx.up._02.async;

import io.vertx.core.AbstractVerticle;

/**
 * @author <a href="http://www.origin-x.cn">lang</a>
 */
public class HiVerticle extends AbstractVerticle {

    @Override
    public void start() {

    }
}
