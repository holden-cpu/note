package io.vertx.up._03.web;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.ext.web.Router;

/**
 * @author <a href="http://www.origin-x.cn">Lang</a>
 */
public class HelloWeb extends AbstractVerticle {

    @Override
    public void start() {
        // 创建HTTP服务器，每个Verticle中可直接使用`vertx`引用Vertx实例
        final HttpServer server = this.vertx.createHttpServer();

        final Router router = Router.router(this.vertx);
        router.route().handler(context -> {
            final HttpServerResponse response = context.response();
            response.putHeader("content-type", "text/plain");
            response.end("Hello Web!");
        });

        // 服务器监听8080端口
        server.requestHandler(router).listen(8080);
    }
}
