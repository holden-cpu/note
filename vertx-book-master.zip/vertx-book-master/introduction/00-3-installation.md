# 本地化

&ensp;&ensp;&ensp;&ensp;《逐陆记》最开始使用`Gitbook Editor`书写，所以可以按照在电脑上形成电子版，并且是Gitbook的格式，下边是本地化流程：

## 1. 下载代码

```shell
git clone https://github.com/silentbalanceyh/vertx-chaser.git
```

## 2. 编译成书

> 确保您的环境中已经安装了docker工具，生成过程使用了docker容器化的gitbook。

```shell
~ >> cd vertx-chaser
~/vertx-chaser >> ./book-build.sh
```

## 3. 启动

>  确保您的电脑中安装了node, serve，则可直接运行根目录中命令启动。

```shell
~/vertx-chaser >> ./book-server.sh

   ┌───────────────────────────────────────────────┐
   │                                               │
   │   Serving!                                    │
   │                                               │
   │   - Local:            http://localhost:1231   │
   │   - On Your Network:  http://10.0.0.6:1231    │
   │                                               │
   │   Copied local address to clipboard!          │
   │                                               │
   └───────────────────────────────────────────────┘
```

启动过后，就可以在浏览器中打开查看了，之所以用`1231`做端口号，是因为12月31日是老婆的生日。

## 4. 问题

在使用gitbook工具的过程中，也许您会随机遇到下边问题：

```shell
Error: ENOENT: no such file or directory, stat ‘/nfs/home/alf/gitbook/foobar/_book/gitbook/gitbook-plugin-lunr/lunr.min.js’
Error: ENOENT: no such file or directory, stat ‘/home/aparra/Documentos/zoi-api/book/_book/gitbook/gitbook-plugin-livereload/plugin.js’
Error: ENOENT: no such file or directory, stat ‘…_book\gitbook\gitbook-plugin-fontsettings\fontsettings.js’
```

解决办法：确认您的目录中包含了`gitbook, gitbook-cli`，然后按照下边教程处理：

```shell
~ >> cd ~/.gitbook/versions/3.2.3/lib/output/website
~/.gitbook/versions/3.2.3/lib/output/website » vim copyPluginAssets.js
```

修改`copyPluginAssets.js`文件中的片段（修改112行），将`confirm`的值修改成**false**：

```js
    return fs.copyDir(
        assetsFolder,
        assetOutputFolder,
        {
            deleteFirst: false,
            overwrite: true,
            confirm: false // Fix Random Issue
        }
    );
```

**附加**：如果您在gitbook安装目录中执行下边命令：

```shell
~/.gitbook/versions » ll                                      
total 0
drwxr-xr-x 22 lang staff 704 Jun 22 14:51 2.6.9
drwxr-xr-x 22 lang staff 704 Jun 22 14:54 3.2.3
```

上述工具中，`2.6.9`是**gitbook-cli**的版本，`3.2.3`则是**gitbook**的版本。