# 目录

## 0. 楔子

* [0.1.目录](/introduction/00-1-table-content.md)
* [0.2.术语](/introduction/00-2-terminology.md)
* [0.3.本地化](/introduction/00-3-installation.md)

## 1. 锋芒乍现

* [1.1.一切从FP开始](/chapter01/01-1-functional-programming.md)
* [1.2.Vert.x基础](/chapter01/01-2-vertx-fundation.md)
* [1.3.Vert.x实例](/chapter01/01-3-vertx-instance.md)
* [1.4.Verticle实例](/chapter01/01-4-verticle-instance.md)
* [1.5.Verticle生命周期](/chapter01/01-5-verticle-lifecycle.md)
* [1.6.Context上下文](/chapter01/01-6-context-environment.md)
* [1.7.EventBus初探](/chapter01/01-7-eventbus-primary.md)

## 2. 精灵谷

* [2.1.JSON](/chapter02/02-1-json.md)
* [2.2.JsonObject和JsonArray](/chapter02/02-2-vertx-json.md)
* [2.3.Buffer](/chapter02/02-3-buffer.md)
* [2.4.Options](/chapter02/02-4-options.md)
* [2.5.Store](/chapter02/02-5-store.md)
* [2.6.Async之役](/chapter02/02-7-async-programming.md)

## 3. 服务之遥

* [3.1.正确打开REST](/chapter03/03-1-restful.md)
* [3.2.HttpServer初赦](/chapter03/03-2-http-server.md)
* [3.3.Router路由管理器](/chapter03/03-3-router-manager.md)
* [3.4.一切都是Handler](/chapter03/03-4-handler.md)
* [3.5.URI设计之路](/chapter03/03-5-uri-design.md)
* [3.6.回归HTTP](/chapter03/03-6-http-detail.md)
* [3.7.会话和共享](/chapter03/03-7-session.md)
* [3.8.认证/授权初探](/chapter03/03-8-authenticate-authorization.md)
* [3.9.EventBus利刃](/chapter03/03-9-eventbus.md)
* [3.10.自定义Codec](/chapter03/03-10-define-codec.md)
* [3.11.Worker让任务更简单](/chapter03/03-11-worker-task.md)
* [3.12.你好！Socket](/chapter03/03-12-web-socket.md)

## 4. 珷玞

* [4.1.Vert.x线程模型](chapter04/04-1-vertx-thread-model.md)
* [4.2.Block黑洞](chapter04/04-2-block-hole.md)
* [4.3.Future传送门](chapter04/04-3-future-transmission.md)
* [4.4.生命周期：启动 vs 请求](chapter04/04-4-startup-and-request.md)
* [4.5.详解Handler](chapter04/04-5-handler-analyzing.md)
* [4.6.Client结构分析](chapter04/04-6-client-structure.md)
* [4.7.Worker银弹？](chapter04/04-7-worker-silver-bullet.md)
* [4.8.Router深度分析](chapter04/04-8-routing.md)
* [4.9.RoutingContext怪诞](chapter04/04-9-routing-context.md)

## 5. 调用之影

* [5.1.IO](chapter05/05-1-io.md)
* [5.2.MySQL](chapter05/05-2-mysql.md)
* [5.3.MongoDB](chapter05/05-3-mongodb.md)
* [5.4.Redis](chapter05/05-4-redis.md)
* [5.5.Email](chapter05/05-5-email.md)
* [5.6.RabbitMQ](chapter05/05-6-rabbit-mq.md)
* [5.7.书写自己的Client](chapter05/05-7-define-client.md)
* [5.8.Jooq外援](chapter05/05-8-extension-jooq.md)
* [5.9.ElasticSearch](chapter05/05-9-es-client.md)
* [5.10.Excel传送门](chapter05/05-10-excel.md)

## 6. 自由之风

* [6.1.聊聊Fluent](chapter06/06-1-fluent.md)
* [6.2.Coroutine模式](chapter06/06-2-coroutine.md)
* [6.3.Java中的Future](chapter06/06-3-java-helper.md)
* [6.4.命令驱动](chapter06/06-4-command.md)
* [6.5.Codegen魔法](chapter06/06-5-codegen.md)

## 7. 康庄大道

* [7.1.再谈安全框架](chapter07/07-1-security-framework.md)
* [7.2.自定义安全框架](chapter07/07-2-custom-security.md)
* [7.3.跨域Cors](chapter07/07-3-cors.md)
* [7.4.让SSL保驾护航](chapter07/07-4-ssl.md)
* [7.5.HTTP 2.0](chapter07/07-5-http2.md)

## 8. 星河奏

* [8.1.注册中心](chapter08/08-1-registry-center.md)
* [8.2.gRPC打通服务通信](chapter08/08-2-grpc-communication.md)
* [8.3.Discovery实战](chapter08/08-3-service-discovery.md)
* [8.4.熔断？](chapter08/08-4-service-circuit.md)
* [8.5.Api Gateway](chapter08/08-5-api-gateway.md)
* [8.6.你的心跳？](chapter08/08-6-health-check.md)
* [8.7.SPI试验田](chapter08/08-7-vert.x-services.md)
* [8.8.完美转发](chapter08/08-8-forwarding.md)

## 9. 碎碎念

* [9.1.Unit新面孔](chapter09/09-1-junit.md)
* [9.2.JSR330之痛](chapter09/09-2-di-jsr330.md)
* [9.3.Vert.x中的集群部署](chapter09/09-3-vertx-cluster.md)
* [9.4.合理容错](chapter09/09-4-exception-resolution.md)
* [9.5.让“调试”更简单](chapter09/09-5-debugging.md)
* [9.6.日志](chapter09/09-6-logging.md)

## 10. 百川归海

* [10.1.Vert.x开发心得](chapter10/10-1-vertx-development.md)
* [10.2.代码设计必修课](chapter10/10-2-code-design.md)
* [10.3.抛砖引玉：零](chapter10/10-3-zero-framework.md)
* [10.4.万恶之源：架构](chapter10/10-4-arch.md)

## 附录1：平行世界

* [R0001 - Rx模式的Vertx/Verticle实例](/horization/hz-0001-vertx-verticle.md)
* [R0002 - Rx模式的Acceptor/Worker实例](/horization/hz-0002-acceptor-worker.md)
* [R0003 - Rx模式的Future，ReactiveX模式](/horization/hz-0003-future.md)

## 附录2：全书引用

* [正章](/reference/ref-1-book-content.md)
* [平行世界](/reference/ref-2-horization.md)

