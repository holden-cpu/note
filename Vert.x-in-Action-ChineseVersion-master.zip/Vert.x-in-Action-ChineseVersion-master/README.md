# Vert.x-in-Action-ChineseVersion
Vert.x-in-Action的中文翻译版.

![Vert.x-in-Action-ChineseVersion](Vert.x-in-Action-ChineseVersion.png)
